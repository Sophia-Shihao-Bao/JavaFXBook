
package com.example.voiturefx;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class BooksController {

    @FXML private TextField bookIdField;
    @FXML private TextField titleField;
    @FXML private TextField authorField;
    @FXML private ComboBox<Genre> genreComboBox;
    @FXML private ListView<String> bookListView;

    private ObservableList<String> bookItems = FXCollections.observableArrayList();
    private BookManager bookManager = new BookManager();

    @FXML
    public void initialize() {
        genreComboBox.setItems(FXCollections.observableArrayList(Genre.values()));
        bookListView.setItems(bookItems);
    }

    @FXML
    private void addBook() {
        try {
            int id = Integer.parseInt(bookIdField.getText());
            String title = titleField.getText();
            String author = authorField.getText();
            Genre genre = genreComboBox.getValue();

            Book book = new Book(id, title, author, genre);
            bookManager.addBook(book);
            bookItems.add(book.toString());

            clearFields();
        } catch (Exception e) {
            showAlert("Invalid input. Please check all fields.");
        }
    }

    @FXML
    private void deleteBook() {
        try {
            int id = Integer.parseInt(bookIdField.getText());
            if (bookManager.deleteBook(id)) {
                refreshList();
                clearFields();
            } else {
                showAlert("Book not found.");
            }
        } catch (NumberFormatException e) {
            showAlert("Please enter a valid Book ID.");
        }
    }

    private void refreshList() {
        bookItems.clear();
        for (Book book : bookManager.getAllBooks()) {
            bookItems.add(book.toString());
        }
    }

    private void clearFields() {
        bookIdField.clear();
        titleField.clear();
        authorField.clear();
        genreComboBox.setValue(null);
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
