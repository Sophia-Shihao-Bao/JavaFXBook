
package com.example.voiturefx;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BookManager manager = new BookManager();
        Scanner scanner = new Scanner(System.in);
        String fileName = "books.txt";

        while (true) {
            System.out.println("\nLibrary Menu:");
            System.out.println("1. Add a new book");
            System.out.println("2. Delete a book");
            System.out.println("3. Display all books");
            System.out.println("4. Search books by author");
            System.out.println("5. Create collection by genre");
            System.out.println("6. Save books to file");
            System.out.println("7. Load books from file");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    System.out.print("Enter book ID: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter genre (FICTION, NON_FICTION, SCIENCE_FICTION, MYSTERY, FANTASY, BIOGRAPHY): ");
                    Genre genre = Genre.valueOf(scanner.nextLine().toUpperCase());
                    manager.addBook(new Book(id, title, author, genre));
                    break;
                case 2:
                    System.out.print("Enter book ID to delete: ");
                    int delId = Integer.parseInt(scanner.nextLine());
                    if (manager.deleteBook(delId)) {
                        System.out.println("Book deleted.");
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                    List<Book> allBooks = manager.getAllBooks();
                    allBooks.forEach(System.out::println);
                    break;
                case 4:
                    System.out.print("Enter author to search: ");
                    String searchAuthor = scanner.nextLine();
                    List<Book> byAuthor = manager.searchByAuthor(searchAuthor);
                    byAuthor.forEach(System.out::println);
                    break;
                case 5:
                    System.out.print("Enter genre to list (FICTION, NON_FICTION, SCIENCE_FICTION, MYSTERY, FANTASY, BIOGRAPHY): ");
                    Genre g = Genre.valueOf(scanner.nextLine().toUpperCase());
                    List<Book> genreBooks = manager.createGenreCollection(g);
                    genreBooks.forEach(System.out::println);
                    break;
                case 6:
                    try {
                        manager.saveToFile(fileName);
                        System.out.println("Books saved to file.");
                    } catch (Exception e) {
                        System.out.println("Error saving: " + e.getMessage());
                    }
                    break;
                case 7:
                    try {
                        manager.loadFromFile(fileName);
                        System.out.println("Books loaded from file.");
                    } catch (Exception e) {
                        System.out.println("Error loading: " + e.getMessage());
                    }
                    break;
                case 0:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
