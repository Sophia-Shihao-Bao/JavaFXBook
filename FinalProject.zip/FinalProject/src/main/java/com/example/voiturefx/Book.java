
package com.example.voiturefx;

public class Book {
    private int bookId;
    private String title;
    private String author;
    private Genre genre;

    public Book(int bookId, String title, String author, Genre genre) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
    }

    public int getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public Genre getGenre() {
        return genre;
    }

    @Override
    public String toString() {
        return "Book ID: " + bookId +
                ", Title: \"" + title + "\"" +
                ", Author: " + author +
                ", Genre: " + genre;
    }

}
