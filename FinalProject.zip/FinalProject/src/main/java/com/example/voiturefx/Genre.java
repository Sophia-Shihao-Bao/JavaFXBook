
package com.example.voiturefx;

public enum Genre {
    FICTION,
    NON_FICTION,
    SCIENCE_FICTION,
    MYSTERY,
    FANTASY,
    BIOGRAPHY
}
