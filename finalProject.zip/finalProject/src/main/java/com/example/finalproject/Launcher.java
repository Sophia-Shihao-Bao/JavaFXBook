package com.example.finalproject;

public class Launcher
{
    public static void main(String[] args)
    {
        CarsApplication.main(args);
    }
}
